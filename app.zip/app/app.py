import os
from flask import Flask, request, render_template, redirect, url_for, flash
import pandas as pd
import matplotlib.pyplot as plt
from werkzeug.utils import secure_filename
import plotly.express as px
import plotly.io as pio

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['STATIC_FOLDER'] = 'static'
app.secret_key = 'your_secret_key'

if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

if not os.path.exists(app.config['STATIC_FOLDER']):
    os.makedirs(app.config['STATIC_FOLDER'])

# Route to upload Excel file
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        file = request.files['file']
        if file and file.filename.endswith('.xlsx'):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            return redirect(url_for('analyze_data', filename=filename))
        else:
            flash('Please upload an Excel file.')
    return render_template('index.html')

# Route to analyze the uploaded Excel file
@app.route('/analyze/<filename>')
def analyze_data(filename):
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    try:
        # Load the Excel file into a DataFrame
        data = pd.read_excel(filepath)

        # Perform some basic analysis (mean, median, etc.)
        analysis = data.describe()

        # ------- Matplotlib Visualization ---------
        plot_filename = 'plot.png'
        plot_path = os.path.join(app.config['STATIC_FOLDER'], plot_filename)

        plt.figure(figsize=(12, 8))  # Adjust figure size for large data
        data.hist(bins=30, edgecolor='black')  # Add edge color for better visibility
        plt.xticks(rotation=45, ha='right')  # Rotate x-axis labels for better readability
        plt.tight_layout()  # Ensures that labels and elements do not overlap
        plt.savefig(plot_path)
        plt.close()

        # ------- Optional: Plotly Visualization for Interactivity ---------
        plotly_filename = 'plotly_plot.html'
        plotly_path = os.path.join(app.config['STATIC_FOLDER'], plotly_filename)

        # Filter only numeric columns for Plotly
        numeric_data = data.select_dtypes(include=['number'])

        if not numeric_data.empty:
            # Generate an interactive plot using Plotly
            plot = px.histogram(numeric_data, title="Data Distribution")
            plot.update_layout(
                xaxis_title="Value",
                yaxis_title="Frequency",
                template="plotly_dark",
                bargap=0.1
            )
            pio.write_html(plot, file=plotly_path)

        # Convert the analysis to HTML for rendering
        analysis_html = analysis.to_html()

        return render_template('report.html', analysis=analysis_html, plot_url=url_for('static', filename=plot_filename), plotly_url=url_for('static', filename=plotly_filename))
    except Exception as e:
        flash(f"Error analyzing the data: {e}")
        return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
